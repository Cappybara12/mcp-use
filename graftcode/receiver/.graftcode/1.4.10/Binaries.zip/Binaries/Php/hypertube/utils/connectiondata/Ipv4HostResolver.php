<?php

declare(strict_types=1);

namespace HypertubePhpUtils\connectiondata;

final class Ipv4HostResolver
{
    public static function resolve(string $hostOnly, string $label): string
    {
        if ($hostOnly === 'localhost') {
            return '127.0.0.1';
        }

        $host = $hostOnly;
        if (strlen($host) > 1 && $host[0] === '[' && substr($host, -1) === ']') {
            $host = substr($host, 1, -1);
        }

        if (filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false) {
            return $host;
        }
        if (filter_var($host, FILTER_VALIDATE_IP) !== false) {
            throw new \InvalidArgumentException(self::ipv4Error($label));
        }

        $ipv4Addresses = gethostbynamel($host);
        if ($ipv4Addresses !== false && count($ipv4Addresses) > 0) {
            return $ipv4Addresses[0];
        }

        $ipv6Records = @dns_get_record($host, DNS_AAAA);
        if (is_array($ipv6Records) && count($ipv6Records) > 0) {
            throw new \InvalidArgumentException(self::ipv4Error($label));
        }

        throw new \InvalidArgumentException('Cannot resolve ' . self::inlineLabel($label) . " hostname '$hostOnly'.");
    }

    private static function ipv4Error(string $label): string
    {
        return $label . ' hostname must resolve to an IPv4 address.';
    }

    private static function inlineLabel(string $label): string
    {
        return strtoupper($label) === $label ? $label : lcfirst($label);
    }
}
