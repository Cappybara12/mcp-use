# frozen_string_literal: true

module Hypertube
  module Utils
    # GUID/UUID string wrapper (Ruby stdlib has no UUID type; used for ParsingArgument dispatch).
    class Uuid
      attr_reader :value

      def initialize(value)
        @value = value
      end

      def to_s
        @value
      end

      def ==(other)
        other.is_a?(Uuid) && other.value == value
      end
    end
  end
end
