# frozen_string_literal: true

module Hypertube
  module Utils
    module Exceptions
      class ExceptionType
        EXCEPTION = 0
        IO_EXCEPTION = 1
        FILE_NOT_FOUND_EXCEPTION = 2
        RUNTIME_EXCEPTION = 3
        ARITHMETIC_EXCEPTION = 4
        ILLEGAL_ARGUMENT_EXCEPTION = 5
        INDEX_OUT_OF_BOUNDS_EXCEPTION = 6
        NULL_POINTER_EXCEPTION = 7
      end
    end
  end
end
