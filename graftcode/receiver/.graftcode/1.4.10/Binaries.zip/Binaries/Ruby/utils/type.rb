# frozen_string_literal: true

module Hypertube
  module Utils
    class Type
      COMMAND = 0
      HT__STRING = 1
      HT__INTEGER = 2
      HT__BOOLEAN = 3
      HT__FLOAT = 4
      HT__BYTE = 5
      HT__CHAR = 6
      HT__LONG_LONG = 7
      HT__DOUBLE = 8
      HT__UNSIGNED_LONG_LONG = 9
      HT__UNSIGNED_INTEGER = 10
      HT__NULL = 11
      HT__UNDEFINED = 12
      HT__VOID = 13
    end
  end
end
