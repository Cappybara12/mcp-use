require 'net/http'
require 'json'
require 'socket'
require 'date'
require_relative './activation_helper'

module Hypertube
  module Sdk
    module Tools
      class MessageHelper
        FALLBACK_ADDRESS = 'https://polandcentral-0.in.applicationinsights.azure.com/v2/track'
        DEFAULT_INSTRUMENTATION_KEY = '87e949af-cf27-489c-8518-591b3b55b667'
        APPINSIGHTS_CONNECTION_STRING_ENV_NAME = 'HYPERTUBE_APPLICATIONINSIGHTS_CONNECTION_STRING'
        REQUEST_TIMEOUT_SECONDS = 3
        CALLING_RUNTIME_NAME = 'Ruby'
        VERSION = Gem.loaded_specs['hypertube-ruby-sdk']&.version&.to_s || 'Unknown'
        NODE_NAME = begin
          Socket.gethostname
        rescue StandardError
          'Unknown Host'
        end
        OS_NAME = case RUBY_PLATFORM
                  when /darwin/ then 'MacOS'
                  when /linux/ then 'Linux'
                  when /freebsd/ then 'FreeBSD'
                  when /mswin|msys|mingw|cygwin|bccwin|wince|emc/ then 'Windows'
                  else 'Unknown'
                  end

        def self.send_message_to_app_insights(operation_name, message)
          thread = Thread.new do
            send_message_to_app_insights_func(operation_name, message)
          end
          thread.abort_on_exception = false
          thread.report_on_exception = false if thread.respond_to?(:report_on_exception=)
          thread
        rescue StandardError
          nil
        end

        def self.send_message_to_app_insights_func(operation_name, message)
          license_key = Hypertube::Sdk::Tools::ActivationHelper.get_license_key
          if message.include?('BinariesUnloader exception') ||
             message.include?('BinariesExtractor exception')
            return 0 if license_key == 'functional-tests-key'
          end

          address, instrumentation_key = resolve_telemetry_target

          payload = {
            'name' => 'AppEvents',
            'time' => Time.now.utc.strftime('%Y-%m-%dT%H:%M:%SZ'),
            'iKey' => instrumentation_key,
            'tags' => {
              'ai.application.ver' => VERSION,
              'ai.cloud.roleInstance' => NODE_NAME,
              'ai.operation.id' => '0',
              'ai.operation.parentId' => '0',
              'ai.operation.name' => operation_name,
              'ai.internal.sdkVersion' => 'hypertube',
              'ai.internal.nodeName' => NODE_NAME
            },
            'data' => {
              'baseType' => 'EventData',
              'baseData' => {
                'ver' => 2,
                'name' => message,
                'properties' => {
                  'OperatingSystem' => OS_NAME,
                  'LicenseKey' => license_key,
                  'CallingTechnology' => CALLING_RUNTIME_NAME
                }
              },
            }
          }

          uri = URI(address)
          request = Net::HTTP::Post.new(uri)
          request['Content-Type'] = 'application/json'
          request.body = JSON.generate(payload)

          response = Net::HTTP.start(
            uri.hostname,
            uri.port,
            use_ssl: true,
            open_timeout: REQUEST_TIMEOUT_SECONDS,
            read_timeout: REQUEST_TIMEOUT_SECONDS
          ) { |http| http.request(request) }

          response.code.to_i
        rescue StandardError
          -1
        end

        def self.resolve_telemetry_target
          connection_string = ENV[APPINSIGHTS_CONNECTION_STRING_ENV_NAME]
          if connection_string.nil? || connection_string.strip.empty?
            return [FALLBACK_ADDRESS, DEFAULT_INSTRUMENTATION_KEY]
          end

          values = parse_connection_string(connection_string)
          ingestion_endpoint = values['ingestionendpoint']
          instrumentation_key = values['instrumentationkey']
          address = FALLBACK_ADDRESS
          unless ingestion_endpoint.nil? || ingestion_endpoint.empty?
            address = "#{ingestion_endpoint.gsub(%r{/+$}, '')}/v2/track"
          end
          if instrumentation_key.nil? || instrumentation_key.empty?
            instrumentation_key = DEFAULT_INSTRUMENTATION_KEY
          end

          [address, instrumentation_key]
        end

        def self.parse_connection_string(connection_string)
          values = {}
          connection_string.split(';').each do |raw_segment|
            segment = raw_segment.strip
            next if segment.empty?

            separator_index = segment.index('=')
            next if separator_index.nil? || separator_index <= 0 || separator_index >= segment.length - 1

            key = segment[0...separator_index].strip.downcase
            value = segment[(separator_index + 1)..].strip
            next if key.empty? || value.empty?

            values[key] = value
          end
          values
        end
      end
    end
  end
end
