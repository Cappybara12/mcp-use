# frozen_string_literal: true
require_relative './connection_data'
require_relative './ipv4_host_resolver'

module Hypertube
  module Utils
    class PluginConnectionData < ConnectionData
      attr_reader :hostname, :ip_address, :port, :plugin_config

      def initialize(hostname, plugin_config)
        super()
        hostname = '127.0.0.1:0' if hostname.nil? || hostname.to_s.strip.empty?
        host_only, port = parse_hostname(hostname)
        @hostname = "#{host_only}:#{port}"
        @port = port
        @plugin_config = plugin_config.to_s
        @ip_address = Ipv4HostResolver.resolve(host_only, 'Plugin')
      end

      def connection_type
        ConnectionType::PLUGIN
      end

      def to_s
        "plugin|#{@hostname}"
      end

      def get_config
        @plugin_config
      end

      def get_address_bytes
        @ip_address.split('.').map(&:to_i)
      end

      def get_port_bytes
        [@port & 0xFF, @port >> 8]
      end

      def serialize_connection_data
        [Hypertube::Utils::ConnectionType::PLUGIN] + get_address_bytes + get_port_bytes
      end

      private

      def parse_hostname(hostname)
        value = hostname.to_s.strip
        scheme_separator = value.index('://')
        value = value[(scheme_separator + 3)..] if scheme_separator && scheme_separator.positive?

        colon = value.rindex(':')
        raise 'Hostname must use host:port format.' if !colon || colon <= 0 || colon >= value.length - 1

        host_only = value[0...colon].strip
        port = Integer(value[(colon + 1)..])
        if host_only.empty? || port.negative? || port > 65_535
          raise 'Hostname must contain a non-empty host and port between 0 and 65535.'
        end

        [host_only, port]
      rescue ArgumentError
        raise 'Hostname must contain a numeric port.'
      end
    end
  end
end
