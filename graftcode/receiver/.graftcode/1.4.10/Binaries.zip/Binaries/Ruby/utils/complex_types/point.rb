# frozen_string_literal: true

module Hypertube
  module Utils
    # 2D point (same wire layout as System.Drawing.Point / java.awt.Point).
    class Point
      attr_reader :x, :y

      def initialize(x, y)
        @x = x
        @y = y
      end

      def ==(other)
        other.is_a?(Point) && other.x == x && other.y == y
      end
    end
  end
end
