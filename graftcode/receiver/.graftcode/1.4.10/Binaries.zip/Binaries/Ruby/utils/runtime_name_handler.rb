# frozen_string_literal: true
require_relative './runtime_name_ht'

module Hypertube
  module Utils
    class RuntimeNameHandler
      def self.get_name(runtime_name)
        if runtime_name == Hypertube::Utils::RuntimeNameHt::CLR
          return 'clr'
        end
        if runtime_name == Hypertube::Utils::RuntimeNameHt::GO
          return 'go'
        end
        if runtime_name == Hypertube::Utils::RuntimeNameHt::JVM
          return 'jvm'
        end
        if runtime_name == Hypertube::Utils::RuntimeNameHt::NETCORE
          return 'netcore'
        end
        if runtime_name == Hypertube::Utils::RuntimeNameHt::PERL
          return 'perl'
        end
        if runtime_name == Hypertube::Utils::RuntimeNameHt::PYTHON
          return 'python'
        end
        if runtime_name == Hypertube::Utils::RuntimeNameHt::RUBY
          return 'ruby'
        end
        if runtime_name == Hypertube::Utils::RuntimeNameHt::NODEJS
          return 'nodejs'
        end
        if runtime_name == Hypertube::Utils::RuntimeNameHt::CPP
          return 'cpp'
        end
        if runtime_name == Hypertube::Utils::RuntimeNameHt::PHP
          return 'php'
        end
        if runtime_name == Hypertube::Utils::RuntimeNameHt::PYTHON27
          return 'python27'
        end
      end

      def self.get_runtime(name)
        if name.nil? || name.strip.empty?
          raise "Runtime name cannot be null or whitespace."
        end
        name = name.strip.downcase
        case name
        when 'clr'
          Hypertube::Utils::RuntimeNameHt::CLR
        when 'go'
          Hypertube::Utils::RuntimeNameHt::GO
        when 'jvm'
          Hypertube::Utils::RuntimeNameHt::JVM
        when 'netcore'
          Hypertube::Utils::RuntimeNameHt::NETCORE
        when 'perl'
          Hypertube::Utils::RuntimeNameHt::PERL
        when 'python'
          Hypertube::Utils::RuntimeNameHt::PYTHON
        when 'ruby'
          Hypertube::Utils::RuntimeNameHt::RUBY
        when 'nodejs'
          Hypertube::Utils::RuntimeNameHt::NODEJS
        when 'php'
          Hypertube::Utils::RuntimeNameHt::PHP
        when 'python27'
          Hypertube::Utils::RuntimeNameHt::PYTHON27
        else
          raise "#{name} is not a supported runtime."
        end
      end
    end
  end
end
