# frozen_string_literal: true

module Hypertube
  module Utils
    # Clock time without date (maps to System.TimeOnly / datetime.time).
    class TimeOfDay
      attr_reader :hour, :min, :sec, :nsec

      def initialize(hour, min, sec, nsec = 0)
        @hour = hour
        @min = min
        @sec = sec
        @nsec = nsec
      end

      def ==(other)
        other.is_a?(TimeOfDay) &&
          other.hour == hour && other.min == min && other.sec == sec && other.nsec == nsec
      end
    end
  end
end
