# frozen_string_literal: true

module Hypertube
  module Utils
    # RGBA color (r, g, b, a); wire order matches System.Drawing / Node ComplexValueType.
    class Color
      attr_reader :r, :g, :b, :a

      def initialize(r, g, b, a = 255)
        @r = r
        @g = g
        @b = b
        @a = a
      end

      def ==(other)
        other.is_a?(Color) && other.r == r && other.g == g && other.b == b && other.a == a
      end
    end
  end
end
