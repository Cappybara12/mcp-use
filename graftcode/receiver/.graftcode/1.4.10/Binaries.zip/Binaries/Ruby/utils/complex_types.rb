# frozen_string_literal: true

require_relative 'complex_types/point'
require_relative 'complex_types/color'
require_relative 'complex_types/duration'
require_relative 'complex_types/uuid'
require_relative 'complex_types/time_of_day'

module Hypertube
  module Utils
    module ComplexTypes
      def self.color_channel(value)
        value.to_i & 0xFF
      end
    end
  end
end
