# frozen_string_literal: true

module Hypertube
  module Utils
    class ConnectionType
      IN_MEMORY = 0
      TCP = 1
      WEB_SOCKET = 2
      HTTP2 = 3
      TCP_TLS = 4
      PLUGIN = 5
    end
  end
end
