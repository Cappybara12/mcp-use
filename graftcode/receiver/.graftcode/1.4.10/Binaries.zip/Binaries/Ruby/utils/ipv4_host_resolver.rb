# frozen_string_literal: true
require 'ipaddr'
require 'socket'

module Hypertube
  module Utils
    module Ipv4HostResolver
      module_function

      def resolve(host_only, label)
        return '127.0.0.1' if host_only == 'localhost'

        host = host_only
        host = host[1...-1] if host.start_with?('[') && host.end_with?(']')

        literal = begin
          IPAddr.new(host)
        rescue IPAddr::Error
          nil
        end
        if literal
          raise ArgumentError, ipv4_error(label) unless literal.ipv4?

          return literal.to_s
        end

        addresses = begin
          Addrinfo.getaddrinfo(host, nil)
        rescue SocketError
          raise ArgumentError, "Cannot resolve #{inline_label(label)} hostname '#{host_only}'."
        end

        ipv4 = addresses.find(&:ipv4?)
        raise ArgumentError, ipv4_error(label) unless ipv4

        ipv4.ip_address
      end

      def ipv4_error(label)
        "#{label} hostname must resolve to an IPv4 address."
      end

      def inline_label(label)
        label.upcase == label ? label : label[0].downcase + label[1..]
      end
    end
  end
end
