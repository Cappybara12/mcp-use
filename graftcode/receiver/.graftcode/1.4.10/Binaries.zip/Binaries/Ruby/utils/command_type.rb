# frozen_string_literal: true

module Hypertube
  module Utils
    class CommandType
      VALUE = 0
      LOAD_LIBRARY = 1
      INVOKE_STATIC_METHOD = 2
      GET_STATIC_FIELD = 3
      SET_STATIC_FIELD = 4
      CREATE_CLASS_INSTANCE = 5
      GET_TYPE = 6
      REFERENCE = 7
      GET_MODULE = 8
      INVOKE_INSTANCE_METHOD = 9
      EXCEPTION = 10
      HEARTBEAT = 11
      CAST = 12
      GET_INSTANCE_FIELD = 13
      OPTIMIZE = 14
      GENERATE_LIB = 15
      INVOKE_GLOBAL_FUNCTION = 16
      DESTRUCT_REFERENCE = 17
      ARRAY_REFERENCE = 18
      ARRAY_GET_ITEM = 19
      ARRAY_GET_SIZE = 20
      ARRAY_GET_RANK = 21
      ARRAY_SET_ITEM = 22
      ARRAY = 23
      RETRIEVE_ARRAY = 24
      SET_INSTANCE_FIELD = 25
      INVOKE_GENERIC_STATIC_METHOD = 26
      INVOKE_GENERIC_METHOD = 27
      GET_ENUM_ITEM = 28
      GET_ENUM_NAME = 29
      GET_ENUM_VALUE = 30
      AS_REF = 31
      AS_OUT = 32
      GET_REF_VALUE = 33
      ENABLE_NAMESPACE = 34
      ENABLE_TYPE = 35
      CREATE_NULL = 36
      GET_STATIC_METHOD_AS_DELEGATE = 37
      GET_INSTANCE_METHOD_AS_DELEGATE = 38
      PASS_DELEGATE = 39
      INVOKE_DELEGATE = 40
      CONVERT_TYPE = 41
      ADD_EVENT_LISTENER = 42
      PLUGIN_WRAPPER = 43
      GET_ASYNC_OPERATION_RESULT = 44
      AS_KWARGS = 45
      GET_RESULT_TYPE = 46
      GET_GLOBAL_FIELD = 47
      REGISTER_FOR_UPDATE = 48
      VALUE_FOR_UPDATE = 49
      AS_DTO = 50 # not used in new version, do not remove for backwards compatibility, check for occurenses before removing
      DTO_PROPERTY = 51 # not used in new version, do not remove for backwards compatibility, check for occurenses before removing
      PROJECT_RESULT_AS_DTO = 52 # not used in new version, do not remove for backwards compatibility, check for occurenses before removing
      PASS_BY_VALUE = 53
      CONTEXT_METADATA = 54
      COMPLEX_VALUE_TYPE = 55

      def self.get_name(command_number)
        case command_number
        when 0
          'VALUE'
        when 1
          'LOAD_LIBRARY'
        when 2
          'INVOKE_STATIC_METHOD'
        when 3
          'GET_STATIC_FIELD'
        when 4
          'SET_STATIC_FIELD'
        when 5
          'CREATE_CLASS_INSTANCE'
        when 6
          'GET_TYPE'
        when 7
          'REFERENCE'
        when 8
          'GET_MODULE'
        when 9
          'INVOKE_INSTANCE_METHOD'
        when 10
          'EXCEPTION'
        when 11
          'HEARTBEAT'
        when 12
          'CAST'
        when 13
          'GET_INSTANCE_FIELD'
        when 14
          'OPTIMIZE'
        when 15
          'GENERATE_LIB'
        when 16
          'INVOKE_GLOBAL_FUNCTION'
        when 17
          'DESTRUCT_REFERENCE'
        when 18
          'ARRAY_REFERENCE'
        when 19
          'ARRAY_GET_ITEM'
        when 20
          'ARRAY_GET_SIZE'
        when 21
          'ARRAY_GET_RANK'
        when 22
          'ARRAY_SET_ITEM'
        when 23
          'ARRAY'
        when 24
          'RETRIEVE_ARRAY'
        when 25
          'SET_INSTANCE_FIELD'
        when 26
          'INVOKE_GENERIC_STATIC_METHOD'
        when 27
          'INVOKE_GENERIC_METHOD'
        when 28
          'GET_ENUM_ITEM'
        when 29
          'GET_ENUM_NAME'
        when 30
          'GET_ENUM_VALUE'
        when 31
          'AS_REF'
        when 32
          'AS_OUT'
        when 33
          'GET_REF_VALUE'
        when 34
          'ENABLE_NAMESPACE'
        when 35
          'ENABLE_TYPE'
        when 36
          'CREATE_NULL'
        when 37
          'GET_STATIC_METHOD_AS_DELEGATE'
        when 38
          'GET_INSTANCE_METHOD_AS_DELEGATE'
        when 39
          'PASS_DELEGATE'
        when 40
          'INVOKE_DELEGATE'
        when 41
          'CONVERT_TYPE'
        when 42
          'ADD_EVENT_LISTENER'
        when 43
          'PLUGIN_WRAPPER'
        when 44
          'GET_ASYNC_OPERATION_RESULT'
        when 48
          'REGISTER_FOR_UPDATE'
        when 49
          'VALUE_FOR_UPDATE'
        when 50
          'AS_DTO'
        when 51
          'DTO_PROPERTY'
        when 52
          'PROJECT_RESULT_AS_DTO'
        when 53
          'PASS_BY_VALUE'
        when 54
          'CONTEXT_METADATA'
        when 55
          'COMPLEX_VALUE_TYPE'
        else
          raise 'Unknown command type'
        end
      end
    end
  end
end
