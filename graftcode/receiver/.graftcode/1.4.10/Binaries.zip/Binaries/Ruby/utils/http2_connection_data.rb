# frozen_string_literal: true
require_relative './connection_data'

module Hypertube
  module Utils
    class Http2ConnectionData < ConnectionData
      DEFAULT_RESPONSE_TIMEOUT_SECONDS = 180

      attr_accessor :hostname, :response_timeout

      def initialize(hostname, response_timeout = DEFAULT_RESPONSE_TIMEOUT_SECONDS)
        super()
        @hostname = hostname
        @response_timeout = response_timeout
      end

      def connection_type
        Hypertube::Utils::ConnectionType::HTTP2
      end

      def serialize_connection_data
        [connection_type, 0, 0, 0, 0, 0, 0]
      end

      def to_s
        "http2|#{@hostname}"
      end

      private

    end
  end
end
