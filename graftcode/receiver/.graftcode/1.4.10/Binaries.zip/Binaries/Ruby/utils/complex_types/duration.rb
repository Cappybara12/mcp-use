# frozen_string_literal: true

module Hypertube
  module Utils
    # Elapsed time in milliseconds (canonical host type for remote TimeSpan / durations).
    class Duration
      attr_reader :milliseconds

      def initialize(milliseconds)
        @milliseconds = milliseconds
      end

      def ==(other)
        other.is_a?(Duration) && other.milliseconds == milliseconds
      end
    end
  end
end
