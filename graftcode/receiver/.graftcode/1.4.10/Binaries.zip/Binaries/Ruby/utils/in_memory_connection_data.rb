# frozen_string_literal: true
require_relative './connection_data'
require_relative './connection_type'

module Hypertube
  module Utils
    class InMemoryConnectionData < ConnectionData
      def initialize
        super()
      end

      def connection_type
        Hypertube::Utils::ConnectionType::IN_MEMORY
      end

      def hostname
        'inmemory'
      end

      def serialize_connection_data
        [connection_type, 0, 0, 0, 0, 0, 0]
      end

      def to_s
        'inmemory|inmemory'
      end
    end
  end
end
