require 'rexml/document'
require 'fileutils'

# frozen_string_literal: true

module Hypertube
  module Sdk
    module Tools
      class ActivationHelper
        @temporary_license_key = 'License key not set'
        @working_directory = ''

        class << self
          attr_accessor :temporary_license_key, :working_directory

          def get_license_key
            get_license_key_from_file
          rescue StandardError
            @temporary_license_key
          end

          private

          def get_license_key_from_file
            file_path = File.join(@working_directory, 'hypertube.lic')
            raise 'License file not found.' unless File.exist?(file_path)

            file = File.read(file_path)
            doc = REXML::Document.new(file)
            ns = 'https://ssl2.hostedwindows.pl/sdncenter-com/'
            activate_result_element = REXML::XPath.first(doc, '//ns:ActivateResult', { 'ns' => ns })
            raise 'ActivateResult element not found in the SOAP response.' if activate_result_element.nil?

            inner_doc = REXML::Document.new(activate_result_element.text)
            license_key_element = REXML::XPath.first(inner_doc, '//ns:licenceKey', { 'ns' => ns })
            raise 'License key not found in the ActivateResult.' if license_key_element.nil?

            license_key_element.text
          end
        end
      end
    end
  end
end
