module Hypertube
  module Core
    module TypeCache
      class TypeCache
        attr_accessor :type_cache

        def self.instance
          @mutex ||= Mutex.new
          @mutex.synchronize do
            @instance ||= new
          end
        end

        private_class_method :new

        def initialize
          @type_cache = []
          @mutex = Mutex.new
        end

        def cache_type(type_regex)
          @mutex.synchronize do
            @type_cache << type_regex
          end
        end

        def is_type_cache_empty?
          @mutex.synchronize do
            @type_cache.empty?
          end
        end

        def is_type_allowed(type_to_check)
          name_to_check = if type_to_check.is_a?(Module)
                            type_to_check.name
                          else
                            "#{type_to_check.class.name}::#{type_to_check.name}"
                          end

          @mutex.synchronize do
            @type_cache.any? do |pattern|
              /#{pattern}/.match?(name_to_check)
            end
          end
        end

        def get_cached_types
          @mutex.synchronize do
            @type_cache.dup
          end
        end

        def clear_cache
          @mutex.synchronize do
            @type_cache.clear
          end
          0
        end
      end
    end
  end
end
