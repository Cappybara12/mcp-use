# frozen_string_literal: true

require_relative 'abstract_handler'

module Hypertube
  module Core
    module Handler
      class ArrayHandler < Hypertube::Core::Handler::AbstractHandler
        def process(command)
          command.payload
        end
      end
    end
  end
end
