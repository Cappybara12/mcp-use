require_relative '../protocol/command_serializer'
require_relative '../protocol/command_deserializer'
require_relative '../handler/handler'
require_relative '../../utils/command'
require_relative '../../utils/command_type'
require_relative '../../utils/message_helper'

module Hypertube
  module Core
    module Interpreter
      class Interpreter
        COMMAND_SENT_FROM_CALLING_SIDE = 'Command sent from calling side'
        COMMAND_RECEIVED_ON_CALLING_SIDE = 'Command received on calling side'
        COMMAND_RECEIVED_ON_CALLED_SIDE = 'Command received on called side'
        RESPONSE_SENT_FROM_CALLED_SIDE = 'Response sent from called side'

        def self.execute(command, connection_data)
          log_debug(COMMAND_SENT_FROM_CALLING_SIDE, command)
          message_byte_array = Hypertube::Core::Protocol::CommandSerializer.serialize(command, connection_data)
          if connection_data.is_a? Utils::WsConnectionData
            require_relative '../web_socket_client/web_socket_client'
            response_byte_array = Hypertube::Core::WebSocketClient::WebSocketClient.send_message(connection_data, message_byte_array)
          elsif connection_data.is_a? Utils::Http2ConnectionData
            require_relative '../http2_client/http2_client'
            response_byte_array = Hypertube::Core::Http2Client::Http2Client.send_message(connection_data, message_byte_array)
          else
            if connection_data.get_headers.length.positive?
              context_metadata_payload = build_context_metadata_payload(command, connection_data)
              command = Hypertube::Utils::Command.new(
                command.runtime_name,
                Hypertube::Utils::CommandType::CONTEXT_METADATA,
                [context_metadata_payload, command]
              )
              message_byte_array = Hypertube::Core::Protocol::CommandSerializer.serialize(command, connection_data)
            end
            if command.runtime_name == Hypertube::Utils::RuntimeNameHt::RUBY && (connection_data.is_a? Utils::InMemoryConnectionData)
              require_relative '../receiver/receiver'
              response_byte_array = Hypertube::Core::Receiver::Receiver.send_command(message_byte_array)[1]
            else
              require_relative '../transmitter/transmitter'
              response_byte_array = Hypertube::Core::Transmitter::Transmitter.send_command(
                message_byte_array,
                message_byte_array.length,
                connection_data.get_config
              )
            end
          end

          response_command = Hypertube::Core::Protocol::CommandDeserializer.deserialize(response_byte_array)
          log_debug(COMMAND_RECEIVED_ON_CALLING_SIDE, response_command)
          response_command
        end

        def self.process(byte_array)
          received_command = Hypertube::Core::Protocol::CommandDeserializer.deserialize(byte_array)
          log_debug(COMMAND_RECEIVED_ON_CALLED_SIDE, received_command)
          response_command = Hypertube::Core::Handler::Handler.handle_command(received_command)
          log_debug(RESPONSE_SENT_FROM_CALLED_SIDE, response_command)
          response_command
        end

        def self.build_context_metadata_payload(command, connection_data)
          metadata_payload = []
          headers = connection_data.get_headers

          headers.each do |key, value|
            metadata_payload << key
            metadata_payload << value
          end

          Hypertube::Utils::Command.new(command.runtime_name, Hypertube::Utils::CommandType::ARRAY, metadata_payload)
        end

        def self.log_debug(label, details)
          return unless ENV['HYPERTUBE_DEBUG']&.casecmp('true')&.zero?

          message = "#{label}: #{details}"
          begin
            puts message
          rescue StandardError
            nil
          end

          begin
            Hypertube::Sdk::Tools::MessageHelper.send_message_to_app_insights('SdkMessage', message)
          rescue StandardError
            nil
          end

          nil
        rescue StandardError
          nil
        end
        private_class_method :log_debug
      end
    end
  end
end
