module Hypertube
  module Core
    module NamespaceCache
      class NamespaceCache
        attr_accessor :namespace_cache

        def self.instance
          @mutex ||= Mutex.new
          @mutex.synchronize do
            @instance ||= new
          end
        end

        private_class_method :new

        def initialize
          @namespace_cache = []
          @mutex = Mutex.new
        end

        def cache_namespace(namespace_regex)
          @mutex.synchronize do
            @namespace_cache << namespace_regex
          end
        end

        def is_namespace_cache_empty?
          @mutex.synchronize do
            @namespace_cache.empty?
          end
        end

        def is_type_allowed(type_to_check)
          name_to_check = if type_to_check.is_a?(Module)
                            type_to_check.name
                          else
                            "#{type_to_check.class.name}"
                          end

          @mutex.synchronize do
            @namespace_cache.any? do |pattern|
              /#{pattern}/.match?(name_to_check)
            end
          end
        end

        def get_cached_namespaces
          @mutex.synchronize do
            @namespace_cache.dup
          end
        end

        def clear_cache
          @mutex.synchronize do
            @namespace_cache.clear
          end
          0
        end
      end
    end
  end
end
