require 'uri'
require 'httpx'
require 'timeout'
require 'socket'

module Hypertube
  module Core
    module Http2Client
      class Http2Client
        MAX_ATTEMPTS = 2
        DEFAULT_CONNECT_TIMEOUT_SECONDS = 120
        DEFAULT_RESPONSE_TIMEOUT_SECONDS = 180
        RESTRICTED_HTTP2_HEADERS = %w[
          connection
          keep-alive
          proxy-connection
          transfer-encoding
          upgrade
          host
        ].freeze

        class Http2TransportError < RuntimeError
        end

        class Http2StatusError < RuntimeError
        end

        @clients = {}
        @clients_lock = Mutex.new

        class << self
          def send_message(connection_data, message)
            raise ArgumentError, 'connection_data cannot be nil' if connection_data.nil?
            raise ArgumentError, 'message cannot be nil' if message.nil?

            begin
              send_message_body(connection_data, message)
            rescue Http2StatusError
              raise
            rescue StandardError
              # Evict desynced/broken connection after final failure (bug 32346).
              close(connection_data)
              raise
            end
          end

          def send_message_body(connection_data, message)
            client = create_or_get_client(connection_data, expected_current: nil)
            last_ex = nil

            MAX_ATTEMPTS.times do |attempt|
              begin
                # Concurrent calls share one HTTPX session, which multiplexes HTTP/2 streams.
                return client.send_bytes(message)
              rescue Http2StatusError
                raise
              rescue StandardError => ex
                last_ex = ex
                break if attempt == MAX_ATTEMPTS - 1
                break unless transient_http2_error?(ex)

                client = create_or_get_client(connection_data, expected_current: client)
              end
            end

            if last_ex
              e = RuntimeError.new("HTTP/2 send to #{connection_key(connection_data)} failed after #{MAX_ATTEMPTS} attempts. Last error: #{last_ex.message}")
              e.set_backtrace(last_ex.backtrace)
              raise e
            end

            raise RuntimeError, "HTTP/2 send to #{connection_key(connection_data)} failed after #{MAX_ATTEMPTS} attempts."
          end

          def close(connection_data)
            client = nil
            @clients_lock.synchronize do
              client = @clients.delete(connection_key(connection_data))
            end
            client&.close
          end

          def get_state(connection_data)
            @clients_lock.synchronize do
              @clients.key?(connection_key(connection_data)) ? :OPEN : nil
            end
          end

          private

          def transient_http2_error?(error)
            return true if error.is_a?(Http2TransportError)
            return true if defined?(HTTPX::TimeoutError) && error.is_a?(HTTPX::TimeoutError)
            return true if defined?(HTTPX::ConnectionError) && error.is_a?(HTTPX::ConnectionError)

            message = error.message.to_s.downcase
            message.include?('timed out') ||
              message.include?('timeout') ||
              message.include?('connection refused') ||
              message.include?('connection reset') ||
              message.include?('empty reply') ||
              message.include?('network is unreachable') ||
              message.include?('broken pipe')
          end

          def connection_key(connection_data)
            if connection_data.respond_to?(:to_canonical_key)
              return connection_data.to_canonical_key
            end
            url = connection_data.respond_to?(:hostname) ? connection_data.hostname : connection_data.to_s
            "http2|#{url}"
          end

          def create_or_get_client(connection_data, expected_current:)
            @clients_lock.synchronize do
              key = connection_key(connection_data)
              if expected_current.nil?
                return @clients[key] if @clients[key]
                created = new(connection_data)
                @clients[key] = created
                return created
              end

              current = @clients[key]
              if current&.equal?(expected_current)
                @clients.delete(key)
                current.close
              end
              recreated = new(connection_data)
              @clients[key] = recreated
              recreated
            end
          end
        end

        def initialize(connection_data)
          @connection_data = connection_data
          @url = connection_data.respond_to?(:hostname) ? connection_data.hostname : connection_data.to_s
          @uri = URI.parse(@url)
          unless %w[http https].include?(@uri.scheme.to_s.downcase)
            raise "Http2Client requires 'http' (h2c) or 'https' (h2 over TLS) scheme. Provided URL: #{@url}"
          end
          @response_timeout = connection_data.respond_to?(:response_timeout) ? connection_data.response_timeout : DEFAULT_RESPONSE_TIMEOUT_SECONDS
          @http_client = build_http_client
        end

        def send_bytes(message)
          payload = normalize_payload(message)
          response = nil
          ensure_server_reachable!
          Timeout.timeout(operation_timeout_seconds) do
            response = @http_client.post(@url, headers: request_headers, body: payload)

            if defined?(HTTPX::ErrorResponse) && response.is_a?(HTTPX::ErrorResponse)
              response_error = response.respond_to?(:error) ? response.error : nil
              details = response_error ? response_error.message : response.to_s
              raise Http2TransportError, "HTTP/2 request to #{@url} failed: #{details}"
            end

            status_code = response.status.to_i
            http_version = response.version.to_s
            if !http_version.empty? && !http_version.start_with?('2')
              raise RuntimeError, "HTTP/2 request to #{@url} failed: the endpoint did not negotiate HTTP/2."
            end

            reason = extract_reason_header(response)
            if status_code < 200 || status_code >= 300
              raise Http2StatusError, "HTTP/2 request to #{@url} failed with status #{status_code} #{reason}. "
            end

            return response.body.to_s.bytes
          end
        rescue Timeout::Error
          timeout_text =
            if @response_timeout && @response_timeout >= 0
              "timed out after #{@response_timeout} seconds"
            else
              "timed out"
            end
          raise Http2TransportError, "HTTP/2 request to #{@url} #{timeout_text}. The server may not be responding."
        rescue StandardError => e
          if timeout_error?(e)
            timeout_text =
              if @response_timeout && @response_timeout >= 0
                "timed out after #{@response_timeout} seconds"
              else
                "timed out"
              end
            raise Http2TransportError, "HTTP/2 request to #{@url} #{timeout_text}. The server may not be responding."
          end
          if defined?(HTTPX::Error) && e.is_a?(HTTPX::Error)
            raise Http2TransportError, "HTTP/2 request to #{@url} failed: #{e.message}. The server may be unavailable or not responding."
          end
          raise
        end

        def close
          return unless @http_client

          if @http_client.respond_to?(:close)
            @http_client.close
          elsif @http_client.respond_to?(:shutdown)
            @http_client.shutdown
          end
        rescue StandardError
          # Best-effort transport cleanup only; callers handle send errors.
        ensure
          @http_client = nil
        end

        private

        def build_http_client
          connect_timeout = effective_connect_timeout
          timeout_options = { connect_timeout: connect_timeout }
          if @response_timeout && @response_timeout >= 0
            timeout_options[:request_timeout] = @response_timeout
          end

          HTTPX.with(
            fallback_protocol: 'h2',
            timeout: timeout_options
          )
        end

        def operation_timeout_seconds
          connect_timeout = effective_connect_timeout
          return connect_timeout unless @response_timeout && @response_timeout >= 0

          connect_timeout + @response_timeout
        end

        def effective_connect_timeout
          connect_timeout = DEFAULT_CONNECT_TIMEOUT_SECONDS
          if @response_timeout && @response_timeout >= 0
            connect_timeout = [connect_timeout, @response_timeout].min
          end
          connect_timeout
        end

        def ensure_server_reachable!
          Socket.tcp(@uri.host, @uri.port, connect_timeout: effective_connect_timeout) do |socket|
            socket.close
          end
        rescue StandardError => e
          raise Http2TransportError, "HTTP/2 connection to #{@url} failed: #{e.message}. The server may be unavailable or not responding."
        end

        def normalize_payload(message)
          case message
          when String
            message.b
          when Array
            message.pack('C*')
          else
            raise ArgumentError, "Unsupported message type: #{message.class}"
          end
        end

        def request_headers
          content_type = 'application/octet-stream'
          headers = {}
          if @connection_data.respond_to?(:get_headers)
            @connection_data.get_headers.each do |key, value|
              next if key.nil? || value.nil?

              normalized = key.to_s.strip.downcase
              next if normalized.empty? || normalized.start_with?(':')
              if RESTRICTED_HTTP2_HEADERS.include?(normalized)
                warn "HTTP/2 header '#{key}' is restricted and was ignored."
                next
              end
              if normalized == 'te' && value.to_s.strip.downcase != 'trailers'
                warn "HTTP/2 header '#{key}' with value '#{value}' is invalid and was ignored."
                next
              end
              if normalized == 'content-type'
                content_type = value.to_s
                next
              end
              headers[normalized] = value.to_s
            end
          end
          headers['content-type'] = content_type
          headers
        end

        def extract_reason_header(response)
          return '' unless response.respond_to?(:headers)

          headers = response.headers
          return '' unless headers.respond_to?(:[])

          reason = headers['x-http2-reason']
          if reason.is_a?(Array)
            return reason.first.to_s
          end
          reason.to_s
        end

        def timeout_error?(error)
          return true if defined?(HTTPX::TimeoutError) && error.is_a?(HTTPX::TimeoutError)
          error.message.to_s.downcase.include?('timeout') || error.message.to_s.downcase.include?('timed out')
        end
      end
    end
  end
end
