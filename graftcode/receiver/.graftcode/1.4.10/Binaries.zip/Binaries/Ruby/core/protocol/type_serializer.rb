require_relative '../../utils/type'
require_relative '../../utils/string_encoding_mode_ht'

module Hypertube
  module Core
    module Protocol
      class TypeSerializer
        private_class_method :new

        # -------- Buffer-writing API (appends raw bytes directly to a binary --------
        # -------- String buffer, avoiding per-item Array allocation + pack). --------

        # Writes the 7-byte command header (type, 4-byte length, runtime, command type)
        # straight into +buffer+ (a binary String), mirroring TypeSerializer.WriteCommandHeader.
        def self.write_command_header(buffer, command)
          buffer << Hypertube::Utils::Type::COMMAND
          write_int32_bytes(buffer, command.payload.length)
          buffer << command.runtime_name
          buffer << command.command_type
        end

        # Writes a primitive payload item straight into +buffer+ (a binary String)
        # without building an intermediate Array per item.
        def self.write_primitive(buffer, payload_item)
          case payload_item
          when nil
            write_nil(buffer)
          when true, false
            write_bool(buffer, payload_item)
          when Integer
            if (-2**31..2**31 - 1).include?(payload_item)
              write_int(buffer, payload_item)
            elsif (-2**63..2**63 - 1).include?(payload_item)
              write_longlong(buffer, payload_item)
            else
              write_ullong(buffer, payload_item)
            end
          when String
            write_string(buffer, payload_item)
          when Float
            write_double(buffer, payload_item)
          else
            raise TypeError, "Unsupported payload item type: #{payload_item.class} for payload item: #{payload_item}."
          end
        end

        def self.write_string(buffer, string_value)
          encoded = string_value.b
          buffer << Hypertube::Utils::Type::HT__STRING
          buffer << Hypertube::Utils::StringEncodingModeHt::UTF8
          write_int32_bytes(buffer, encoded.bytesize)
          buffer << encoded
        end

        def self.write_int(buffer, int_value)
          buffer << Hypertube::Utils::Type::HT__INTEGER
          buffer << 4
          write_int32_bytes(buffer, int_value)
        end

        def self.write_bool(buffer, bool_value)
          buffer << Hypertube::Utils::Type::HT__BOOLEAN
          buffer << 1
          buffer << (bool_value ? 1 : 0)
        end

        def self.write_float(buffer, float_value)
          buffer << Hypertube::Utils::Type::HT__FLOAT
          buffer << 4
          buffer << [float_value].pack('e')
        end

        def self.write_byte(buffer, byte_value)
          buffer << Hypertube::Utils::Type::HT__BYTE
          buffer << 1
          buffer << (byte_value & 0xFF)
        end

        def self.write_char(buffer, char_value)
          buffer << Hypertube::Utils::Type::HT__CHAR
          buffer << 1
          buffer << (char_value & 0xFF)
        end

        def self.write_longlong(buffer, longlong_value)
          buffer << Hypertube::Utils::Type::HT__LONG_LONG
          buffer << 8
          write_int64_bytes(buffer, longlong_value)
        end

        def self.write_double(buffer, double_value)
          buffer << Hypertube::Utils::Type::HT__DOUBLE
          buffer << 8
          buffer << [double_value].pack('E')
        end

        def self.write_uint(buffer, uint_value)
          buffer << Hypertube::Utils::Type::HT__UNSIGNED_INTEGER
          buffer << 4
          write_int32_bytes(buffer, uint_value)
        end

        def self.write_ullong(buffer, ullong_value)
          buffer << Hypertube::Utils::Type::HT__UNSIGNED_LONG_LONG
          buffer << 8
          write_int64_bytes(buffer, ullong_value)
        end

        def self.write_nil(buffer)
          buffer << Hypertube::Utils::Type::HT__NULL
          buffer << 1
          buffer << 0
        end

        # Appends the 4 little-endian bytes of +value+ directly to +buffer+.
        # Relies on Ruby's Integer#& treating negative values as infinite two's
        # complement, so this is correct for both signed and unsigned inputs.
        def self.write_int32_bytes(buffer, value)
          buffer << (value & 0xFF)
          buffer << ((value >> 8) & 0xFF)
          buffer << ((value >> 16) & 0xFF)
          buffer << ((value >> 24) & 0xFF)
        end

        # Appends the 8 little-endian bytes of +value+ directly to +buffer+.
        def self.write_int64_bytes(buffer, value)
          buffer << (value & 0xFF)
          buffer << ((value >> 8) & 0xFF)
          buffer << ((value >> 16) & 0xFF)
          buffer << ((value >> 24) & 0xFF)
          buffer << ((value >> 32) & 0xFF)
          buffer << ((value >> 40) & 0xFF)
          buffer << ((value >> 48) & 0xFF)
          buffer << ((value >> 56) & 0xFF)
        end
      end
    end
  end
end
