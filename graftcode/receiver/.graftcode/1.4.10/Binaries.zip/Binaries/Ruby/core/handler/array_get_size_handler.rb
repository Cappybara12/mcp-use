# frozen_string_literal: true

require_relative 'abstract_handler'

module Hypertube
  module Core
    module Handler
      class ArrayGetSizeHandler < Hypertube::Core::Handler::AbstractHandler
        def initialize
          @required_parameters_count = 1
        end

        def process(command)
          validate(command, @required_parameters_count, self.class.name)

          return get_size_array(command) if command.payload[0].is_a? Array

          get_size(command)
        end

        def get_size_array(command)
          array = command.payload[0]
          size = 1
          while array.is_a? Array
            size *= array.length
            array = array[0]
          end
          size
        end

        def get_size(command)
          command.payload[0].length
        end
      end
    end
  end
end
