# frozen_string_literal: true

require 'uri'
require 'time'
require_relative '../../utils/command'
require_relative '../../utils/command_type'
require_relative '../../utils/runtime_name_ht'
require_relative '../../utils/complex_types'

module Hypertube
  module Core
    module ValueTypesParser
      module ValueTypeParserHelpers
        module_function

        def time_to_iso(value)
          value.utc.iso8601(3).sub(/Z\z/, '+00:00')
        end
      end

      class ValueTypeParser
        class << self
          def parsable_value_type?(value)
            PARSABLE.keys.any? { |klass| value.is_a?(klass) }
          end

          def parsable_class?(klass)
            PARSABLE.key?(klass)
          end

          def get_command_for_parsable_value_type(value, runtime_name)
            klass = PARSABLE.keys.find { |key| value.is_a?(key) }
            PARSABLE.fetch(klass).call(value, runtime_name)
          end

          PARSABLE = {
            Time => lambda do |value, runtime_name|
              Hypertube::Utils::Command.new(
                runtime_name,
                Hypertube::Utils::CommandType::COMPLEX_VALUE_TYPE,
                'Time',
                ValueTypeParserHelpers.time_to_iso(value)
              )
            end,
            URI => lambda do |value, runtime_name|
              Hypertube::Utils::Command.new(
                runtime_name,
                Hypertube::Utils::CommandType::COMPLEX_VALUE_TYPE,
                'URI',
                value.to_s
              )
            end,
            Hypertube::Utils::Uuid => lambda do |value, runtime_name|
              Hypertube::Utils::Command.new(
                runtime_name,
                Hypertube::Utils::CommandType::COMPLEX_VALUE_TYPE,
                'Hypertube::Utils::Uuid',
                value.value
              )
            end,
            Hypertube::Utils::Duration => lambda do |value, runtime_name|
              Hypertube::Utils::Command.new(
                runtime_name,
                Hypertube::Utils::CommandType::COMPLEX_VALUE_TYPE,
                'Hypertube::Utils::Duration',
                value.milliseconds
              )
            end,
            Hypertube::Utils::TimeOfDay => lambda do |value, runtime_name|
              iso = format('%02d:%02d:%02d', value.hour, value.min, value.sec)
              Hypertube::Utils::Command.new(
                runtime_name,
                Hypertube::Utils::CommandType::COMPLEX_VALUE_TYPE,
                'Hypertube::Utils::TimeOfDay',
                iso
              )
            end,
            Hypertube::Utils::Point => lambda do |value, runtime_name|
              Hypertube::Utils::Command.new(
                runtime_name,
                Hypertube::Utils::CommandType::COMPLEX_VALUE_TYPE,
                'Hypertube::Utils::Point',
                value.x,
                value.y
              )
            end,
            Hypertube::Utils::Color => lambda do |value, runtime_name|
              Hypertube::Utils::Command.new(
                runtime_name,
                Hypertube::Utils::CommandType::COMPLEX_VALUE_TYPE,
                'Hypertube::Utils::Color',
                value.a,
                value.r,
                value.g,
                value.b
              )
            end
          }.freeze
        end
      end
    end
  end
end
