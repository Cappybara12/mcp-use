# frozen_string_literal: true

require_relative 'abstract_handler'

module Hypertube
  module Core
    module Handler
      class OptimizeHandler < Hypertube::Core::Handler::AbstractHandler
        def process(_command)
          raise "#{self.class} is not implemented in Ruby"
        end
      end
    end
  end
end
