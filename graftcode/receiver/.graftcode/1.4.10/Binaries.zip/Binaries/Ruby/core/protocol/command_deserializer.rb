require_relative 'type_deserializer'
require_relative '../../utils/type'
require_relative '../../utils/command'
require_relative '../../utils/string_encoding_mode_ht'
require_relative '../../utils/command_type'
require_relative '../../utils/runtime_name_ht'

module Hypertube
  module Core
    module Protocol
      class CommandDeserializer
        private_class_method :new

        def self.deserialize(buffer)
          state = { buffer: buffer, position: 11 }
          runtime_name = buffer[0]
          command_type = buffer[10]
          payload = []

          while state[:position] < buffer.length
            payload << read_object(state, buffer[state[:position]])
          end

          Hypertube::Utils::Command.new(runtime_name, command_type, payload)
        end

        def self.read_object(state, type_num)
          case type_num
          when Hypertube::Utils::Type::COMMAND
            read_command(state)
          when Hypertube::Utils::Type::HT__STRING
            read_string(state)
          when Hypertube::Utils::Type::HT__INTEGER
            read_int(state)
          when Hypertube::Utils::Type::HT__BOOLEAN
            read_bool(state)
          when Hypertube::Utils::Type::HT__FLOAT
            read_float(state)
          when Hypertube::Utils::Type::HT__BYTE
            read_byte(state)
          when Hypertube::Utils::Type::HT__CHAR
            read_char(state)
          when Hypertube::Utils::Type::HT__LONG_LONG
            read_longlong(state)
          when Hypertube::Utils::Type::HT__DOUBLE
            read_double(state)
          when Hypertube::Utils::Type::HT__UNSIGNED_LONG_LONG
            read_ullong(state)
          when Hypertube::Utils::Type::HT__UNSIGNED_INTEGER
            read_uint(state)
          when Hypertube::Utils::Type::HT__NULL
            read_nil(state)
          when Hypertube::Utils::Type::HT__UNDEFINED
            read_undefined(state)
          else
            raise Exception.new("Hypertube::Utils::Type #{type_num} not supported in command deserializer")
          end
        end
        private_class_method :read_object

        def self.read_command(state)
          buffer = state[:buffer]
          p = state[:position]
          number_of_elements_in_payload = Hypertube::Core::Protocol::TypeDeserializer.deserialize_int(buffer, p + 1)
          runtime = buffer[p + 5]
          command_type = buffer[p + 6]
          state[:position] += 7

          payload = []
          i = 0
          while i < number_of_elements_in_payload
            payload << read_object(state, buffer[state[:position]])
            i += 1
          end
          Hypertube::Utils::Command.new(runtime, command_type, payload)
        end
        private_class_method :read_command

        def self.read_string(state)
          buffer = state[:buffer]
          p = state[:position]
          string_encoding_mode = buffer[p + 1]
          size = Hypertube::Core::Protocol::TypeDeserializer.deserialize_int(buffer, p + 2)
          state[:position] += 6
          p = state[:position]
          state[:position] += size
          Hypertube::Core::Protocol::TypeDeserializer.deserialize_string(string_encoding_mode, buffer[p...p + size])
        end
        private_class_method :read_string

        def self.read_int(state)
          buffer = state[:buffer]
          state[:position] += 2
          p = state[:position]
          state[:position] += 4
          Hypertube::Core::Protocol::TypeDeserializer.deserialize_int(buffer, p)
        end
        private_class_method :read_int

        def self.read_bool(state)
          buffer = state[:buffer]
          state[:position] += 2
          p = state[:position]
          state[:position] += 1
          Hypertube::Core::Protocol::TypeDeserializer.deserialize_bool(buffer, p)
        end
        private_class_method :read_bool

        def self.read_float(state)
          buffer = state[:buffer]
          state[:position] += 2
          p = state[:position]
          state[:position] += 4
          Hypertube::Core::Protocol::TypeDeserializer.deserialize_float(buffer, p)
        end
        private_class_method :read_float

        def self.read_byte(state)
          buffer = state[:buffer]
          state[:position] += 2
          p = state[:position]
          state[:position] += 1
          Hypertube::Core::Protocol::TypeDeserializer.deserialize_byte(buffer, p)
        end
        private_class_method :read_byte

        def self.read_char(state)
          buffer = state[:buffer]
          state[:position] += 2
          p = state[:position]
          state[:position] += 1
          Hypertube::Core::Protocol::TypeDeserializer.deserialize_char(buffer, p)
        end
        private_class_method :read_char

        def self.read_longlong(state)
          buffer = state[:buffer]
          state[:position] += 2
          p = state[:position]
          state[:position] += 8
          Hypertube::Core::Protocol::TypeDeserializer.deserialize_longlong(buffer, p)
        end
        private_class_method :read_longlong

        def self.read_double(state)
          buffer = state[:buffer]
          state[:position] += 2
          p = state[:position]
          state[:position] += 8
          Hypertube::Core::Protocol::TypeDeserializer.deserialize_double(buffer, p)
        end
        private_class_method :read_double

        def self.read_ullong(state)
          buffer = state[:buffer]
          state[:position] += 2
          p = state[:position]
          state[:position] += 8
          Hypertube::Core::Protocol::TypeDeserializer.deserialize_ullong(buffer, p)
        end
        private_class_method :read_ullong

        def self.read_uint(state)
          buffer = state[:buffer]
          state[:position] += 2
          p = state[:position]
          state[:position] += 4
          Hypertube::Core::Protocol::TypeDeserializer.deserialize_uint(buffer, p)
        end
        private_class_method :read_uint

        def self.read_nil(state)
          buffer = state[:buffer]
          state[:position] += 2
          p = state[:position]
          state[:position] += 1
          Hypertube::Core::Protocol::TypeDeserializer.deserialize_nil(buffer, p)
        end
        private_class_method :read_nil

        def self.read_undefined(state)
          buffer = state[:buffer]
          state[:position] += 2
          p = state[:position]
          state[:position] += 1
          Hypertube::Core::Protocol::TypeDeserializer.deserialize_undefined(buffer, p)
        end
        private_class_method :read_undefined
      end
    end
  end
end
