# frozen_string_literal: true

require_relative 'abstract_handler'

module Hypertube
  module Core
    module Handler
      class ValueForUpdateHandler < Hypertube::Core::Handler::AbstractHandler
        def process(_command)
          raise "#{self.class} is not implemented in Ruby"
        rescue Exception => e
          e
        end
      end
    end
  end
end
