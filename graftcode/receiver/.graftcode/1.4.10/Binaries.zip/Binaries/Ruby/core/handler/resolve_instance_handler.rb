# frozen_string_literal: true

require_relative '../reference_cache/references_cache'
require_relative 'abstract_handler'
require_relative '../../utils/runtime_name_ht'
require_relative '../../utils/command'

module Hypertube
  module Core
    module Handler
      class ResolveInstanceHandler < Hypertube::Core::Handler::AbstractHandler
        def initialize
          @required_parameters_count = 1
        end

        def process(command)
          resolve_reference(command)
        end

        def resolve_reference(command)
          validate(command, @required_parameters_count, self.class.name)

          if command.runtime_name == Hypertube::Utils::RuntimeNameHt::RUBY
            return Hypertube::Core::ReferenceCache::ReferencesCache.instance.resolve_reference(command.payload[0])
          end

          Hypertube::Utils::Command.new(command.runtime_name, Hypertube::Utils::CommandType::REFERENCE, command.payload[0])
        end
      end
    end
  end
end
