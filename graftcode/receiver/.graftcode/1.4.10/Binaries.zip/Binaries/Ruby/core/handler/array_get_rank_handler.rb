# frozen_string_literal: true

require_relative 'abstract_handler'

module Hypertube
  module Core
    module Handler
      class ArrayGetRankHandler < Hypertube::Core::Handler::AbstractHandler
        def initialize
          @required_parameters_count = 1
        end

        def process(command)
          validate(command, @required_parameters_count, self.class.name)

          array = command.payload[0]
          rank = 0
          while array.is_a? Array
            rank += 1
            array = array[0]
          end
          rank
        end
      end
    end
  end
end
