# frozen_string_literal: true

require_relative 'abstract_handler'

module Hypertube
  module Core
    module Handler
      class RegisterForUpdateHandler < Hypertube::Core::Handler::AbstractHandler
        def initialize
          @required_parameters_count = 2
        end

        def self.get_or_create_context_dict
          Thread.current[:register_for_update_handler_context] ||= {}
        end

        def process(command)
          validate(command, @required_parameters_count, self.class.name)

          obj_to_register = command.payload[0]

          guid_to_register = nil
          guid_to_register = command.payload[1].to_s.strip.downcase if command.payload.length > 1 && command.payload[1]

          ctx = self.class.get_or_create_context_dict
          ctx[guid_to_register] = obj_to_register
          obj_to_register
        end
      end
    end
  end
end
