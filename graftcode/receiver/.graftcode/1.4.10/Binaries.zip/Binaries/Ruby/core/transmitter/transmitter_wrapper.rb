module Hypertube
  module Core
    module Transmitter
      module TransmitterWrapper
        extend FFI::Library

        LOAD_MUTEX = Mutex.new
        @loaded = false

        # Idempotent, thread-safe one-time load of the native library and its
        # attached functions (check-then-load under lock with double-check).
        def self.ensure_loaded
          return if @loaded

          LOAD_MUTEX.synchronize do
            return if @loaded

            arch = case FFI::Platform::ARCH
                   when 'x86_64'
                     'X64'
                   when 'x86'
                     'X86'
                   when 'arm'
                     'ARM'
                   when 'aarch64'
                     'ARM64'
                   else
                     raise "Unsupported architecture: #{FFI::Platform::ARCH}"
                   end

            if OS.linux?
              ffi_lib File.expand_path("../../../Binaries/Native/Linux/#{arch}/libHypertubeRubyRuntimeNative.so", __FILE__)
            elsif OS.mac?
              ffi_lib File.expand_path("../../../Binaries/Native/MacOs/#{arch}/libHypertubeRubyRuntimeNative.dylib", __FILE__)
            else
              RubyInstaller::Runtime.add_dll_directory(File.expand_path("../../../Binaries/Native/Windows/#{arch}/", __FILE__))
              ffi_lib File.expand_path("../../../Binaries/Native/Windows/#{arch}/HypertubeRubyRuntimeNative.dll", __FILE__)
            end

            attach_function :SendCommand, [:pointer, :int, :string], :int, blocking: true
            attach_function :ReadResponse, [:pointer, :int], :int, blocking: true
            attach_function :Activate, [:pointer], :int
            attach_function :GetNativeError, [], :string
            attach_function :SetConfigSource, [:pointer], :int
            attach_function :SetWorkingDirectory, [:pointer], :int

            @loaded = true
          end
        end
      end
    end
  end
end
