# frozen_string_literal: true

require_relative 'abstract_handler'

module Hypertube
  module Core
    module Handler
      class ValueHandler < Hypertube::Core::Handler::AbstractHandler
        def process(command)
          command.payload[0]
        end
      end
    end
  end
end
