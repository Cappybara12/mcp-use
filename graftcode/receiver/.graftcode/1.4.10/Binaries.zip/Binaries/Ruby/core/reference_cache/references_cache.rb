module Hypertube
  module Core
    module ReferenceCache
      class ReferencesCache
        private_class_method :new

        def self.instance
          @mutex ||= Mutex.new
          @mutex.synchronize do
            @instance ||= new
          end
        end

        def initialize
          @references_cache = {}
          @mutex = Mutex.new
        end

        def cache_reference(object_reference)
          uuid_ = generate_uuid
          @mutex.synchronize do
            @references_cache[uuid_] = object_reference
          end
          uuid_
        end

        def resolve_reference(guid)
          @mutex.synchronize do
            raise "Unable to resolve reference with id: #{guid}" if @references_cache[guid].nil?

            @references_cache[guid]
          end
        end

        def delete_reference(guid)
          return false if guid.nil?

          @mutex.synchronize do
            return false unless @references_cache.key?(guid)

            @references_cache.delete(guid)
            true
          end
        end

        def generate_uuid
          [8, 4, 4, 4, 12].map { |n| rand(16**n).to_s(16).rjust(n, '0') }.join('-')
        end
        private :generate_uuid
      end
    end
  end
end
