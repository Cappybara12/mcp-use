# frozen_string_literal: true

require_relative 'abstract_handler'

module Hypertube
  module Core
    module Handler
      class GetInstanceFieldHandler < Hypertube::Core::Handler::AbstractHandler
        def initialize
          @required_parameters_count = 2
        end

        def process(command)
          get_instance_field(command)
        end

        def get_instance_field(command)
          validate(command, @required_parameters_count, self.class.name)

          instance = command.payload[0]
          value = command.payload[1].to_s

          field = value.start_with?('@') ? value : "@#{value}"
          field_defined = begin
            instance.instance_variable_defined?(field)
          rescue NameError
            false
          end

          unless field_defined
            fields = instance.instance_variables
            message = "Field #{value} not found in object of class #{instance.class.name}. Available fields:\n"
            fields.each { |field_iter| message += "#{field_iter}\n" }
            raise ArgumentError, message
          end
          instance.instance_variable_get(field)
        end
      end
    end
  end
end
