# frozen_string_literal: true

require_relative 'abstract_handler'
require_relative 'get_type_handler'
require_relative 'array_handler'
require_relative '../../utils/command'

module Hypertube
  module Core
    module Handler
      class ContextMetadataHandler < Hypertube::Core::Handler::AbstractHandler
        def initialize
          @required_parameters_count = 1
          @get_type_handler = GetTypeHandler.new
          @array_handler = ArrayHandler.new
        end

        def process(command)
          validate(command, @required_parameters_count, self.class.name)

          get_type_command = Utils::Command.new(Utils::RuntimeNameHt::RUBY, Utils::CommandType::GET_TYPE, "Graftcode::Context::RequestContext")
          context_type = @get_type_handler.process(get_type_command)
          current_context = context_type.current

          raise "Context metadata payload must contain an array command." if command.payload.nil? || command.payload.empty?

          array_command = command.payload[0]
          if array_command.is_a?(Utils::Command) && array_command.command_type == Utils::CommandType::ARRAY
            values = @array_handler.process(array_command)

            if values.length % 2 != 0
              raise "Context metadata payload must contain key/value pairs."
            end

            headers = {}
            (0...values.length).step(2) do |i|
              key = values[i]
              if key.nil? || key.to_s.strip.empty?
                raise "Context metadata key cannot be null or empty."
              end

              headers[key] = values[i + 1]
            end

            current_context.set_headers(headers)
          else
            raise "Context metadata payload must be an array."
          end

          0
        end
      end
    end
  end
end
