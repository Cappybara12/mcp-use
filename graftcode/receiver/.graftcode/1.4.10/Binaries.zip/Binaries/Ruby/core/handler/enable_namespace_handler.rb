# frozen_string_literal: true

require_relative 'abstract_handler'
require_relative '../namespace_cache/namespace_cache'

module Hypertube
  module Core
    module Handler
      class EnableNamespaceHandler < Hypertube::Core::Handler::AbstractHandler
        def initialize
          @required_parameters_count = 1
        end

        def process(command)
          validate(command, @required_parameters_count, self.class.name)

          namespace_cache = Hypertube::Core::NamespaceCache::NamespaceCache.instance

          command.payload.each do |payload|
            if payload.is_a? String
              namespace_cache.cache_namespace(payload)
            elsif payload.is_a? Array
              payload.each do |type_to_enable|
                namespace_cache.cache_namespace(type_to_enable)
                cache_namespace
              end
            end
          end
          0
        end
      end
    end
  end
end
