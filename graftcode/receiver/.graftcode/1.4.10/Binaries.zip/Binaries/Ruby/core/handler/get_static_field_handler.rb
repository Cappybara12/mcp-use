# frozen_string_literal: true

require_relative 'abstract_handler'

module Hypertube
  module Core
    module Handler
      class GetStaticFieldHandler < Hypertube::Core::Handler::AbstractHandler
        def initialize
          @required_parameters_count = 2
        end

        def process(command)
          get_static_field(command)
        end

        def get_static_field(command)
          validate(command, @required_parameters_count, self.class.name)

          type = command.payload[0]
          value = command.payload[1].to_s

          class_variable_defined = begin
            type.class_variable_defined?(value)
          rescue NameError
            false
          end
          return type.class_variable_get(value) if class_variable_defined

          constant_defined = begin
            type.const_defined?(value)
          rescue NameError
            false
          end
          return type.const_get(value) if constant_defined

          class_variables = type.class_variables
          message = "Field #{value} not found in object of class #{type.class.name}. Available fields:\n"
          class_variables.each { |field_iter| message += "#{field_iter}\n" }
          raise ArgumentError, message
        end
      end
    end
  end
end
