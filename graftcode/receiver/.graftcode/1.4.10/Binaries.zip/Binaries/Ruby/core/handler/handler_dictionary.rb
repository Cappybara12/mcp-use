# frozen_string_literal: true

$handler_dict = {}

module Hypertube
  module Core
    module Handler
      class HandlerDictionary
        def self.add_handler_to_dict(command_type, handler)
          $handler_dict[command_type] = handler
        end
      end
    end
  end
end
