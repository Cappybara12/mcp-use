require_relative '../../utils/string_encoding_mode_ht'

module Hypertube
  module Core
    module Protocol
      class TypeDeserializer
        private_class_method :new

        def self.deserialize_command(command_byte_array)
          Hypertube::Utils::Command.new(Hypertube::Utils::RuntimeNameHt(command_byte_array[0]),
                      Hypertube::Utils::CommandType(command_byte_array[1]),
                      [])
        end

        def self.deserialize_string(string_encoding_mode, encoded_string)
          raw = encoded_string.pack('C*')
          case string_encoding_mode
          when Hypertube::Utils::StringEncodingModeHt::ASCII
            raw.force_encoding('US-ASCII').encode('UTF-8')
          when Hypertube::Utils::StringEncodingModeHt::UTF8
            raw.force_encoding('UTF-8').encode('UTF-8')
          when Hypertube::Utils::StringEncodingModeHt::UTF16
            raw.force_encoding('UTF-16LE').encode('UTF-8')
          when Hypertube::Utils::StringEncodingModeHt::UTF32
            raw.force_encoding('UTF-32').encode('UTF-8')
          else
            raise 'Argument out of range in deserialize_string'
          end
        end

        # Offset-based: reads directly from +bytes+ (Array<Integer>) at +offset+
        # using bit-shift arithmetic instead of allocating a slice + pack/unpack1.
        # Ruby's Integer#& treats negative numbers as infinite two's complement,
        # so the sign-fixup below is the only extra step needed vs. an unsigned read.
        def self.deserialize_int(bytes, offset = 0)
          value = deserialize_uint(bytes, offset)
          value >= 0x80000000 ? value - 0x100000000 : value
        end

        def self.deserialize_bool(bytes, offset = 0)
          bytes[offset] == 1
        end

        def self.deserialize_float(bytes, offset = 0)
          raw = deserialize_uint(bytes, offset)
          [raw].pack('L<').unpack1('e')            # reinterpret 32-bit pattern as IEEE-754 float
        end

        def self.deserialize_byte(bytes, offset = 0)
          bytes[offset] & 0xFF
        end

        def self.deserialize_char(bytes, offset = 0)
          bytes[offset] & 0xFF                     # returns codepoint 0..255
        end

        def self.deserialize_longlong(bytes, offset = 0)
          value = deserialize_ullong(bytes, offset)
          value >= 0x8000000000000000 ? value - 0x10000000000000000 : value
        end

        def self.deserialize_double(bytes, offset = 0)
          raw = deserialize_ullong(bytes, offset)
          [raw].pack('Q<').unpack1('E')            # reinterpret 64-bit pattern as IEEE-754 double
        end

        def self.deserialize_ullong(bytes, offset = 0)
          (bytes[offset] & 0xFF) |
            ((bytes[offset + 1] & 0xFF) << 8) |
            ((bytes[offset + 2] & 0xFF) << 16) |
            ((bytes[offset + 3] & 0xFF) << 24) |
            ((bytes[offset + 4] & 0xFF) << 32) |
            ((bytes[offset + 5] & 0xFF) << 40) |
            ((bytes[offset + 6] & 0xFF) << 48) |
            ((bytes[offset + 7] & 0xFF) << 56)
        end

        def self.deserialize_uint(bytes, offset = 0)
          (bytes[offset] & 0xFF) |
            ((bytes[offset + 1] & 0xFF) << 8) |
            ((bytes[offset + 2] & 0xFF) << 16) |
            ((bytes[offset + 3] & 0xFF) << 24)
        end

        def self.deserialize_nil(_encoded_nil, _offset = 0)
          nil
        end

        def self.deserialize_undefined(_encoded_undefined, _offset = 0)
          nil
        end
      end
    end
  end
end
