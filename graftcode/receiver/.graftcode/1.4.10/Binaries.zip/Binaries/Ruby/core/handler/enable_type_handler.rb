# frozen_string_literal: true

require_relative 'abstract_handler'
require_relative '../type_cache/type_cache'

module Hypertube
  module Core
    module Handler
      class EnableTypeHandler < Hypertube::Core::Handler::AbstractHandler
        def initialize
          @required_parameters_count = 1
        end

        def process(command)
          validate(command, @required_parameters_count, self.class.name)

          type_cache = Hypertube::Core::TypeCache::TypeCache.instance

          command.payload.each do |payload|
            if payload.is_a? String
              type_cache.cache_type(payload)
            elsif payload.is_a? Array
              payload.each do |type_to_enable|
                type_cache.cache_type(type_to_enable)
              end
            end
          end
          0
        end
      end
    end
  end
end
