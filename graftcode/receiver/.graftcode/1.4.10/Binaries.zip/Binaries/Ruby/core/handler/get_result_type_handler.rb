# frozen_string_literal: true

require_relative 'abstract_handler'

module Hypertube
  module Core
    module Handler
      class GetResultTypeHandler < Hypertube::Core::Handler::AbstractHandler
        def initialize
          @required_parameters_count = 1
        end

        def process(command)
          validate(command, @required_parameters_count, self.class.name)
          return 'null' if command.payload[0].nil?

          command.payload[0].class.name || command.payload[0].class.to_s
        end
      end
    end
  end
end
