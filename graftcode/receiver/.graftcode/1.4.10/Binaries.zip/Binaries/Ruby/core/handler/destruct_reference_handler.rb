# frozen_string_literal: true

require_relative 'abstract_handler'
require_relative '../reference_cache/references_cache'

module Hypertube
  module Core
    module Handler
      class DestructReferenceHandler < Hypertube::Core::Handler::AbstractHandler
        def initialize
          @required_parameters_count = 1
        end

        def process(command)
          begin
            validate(command, @required_parameters_count, self.class.name)
          rescue StandardError
            return false
          end

          return false unless command.payload.length == @required_parameters_count

          reference_id = command.payload[0]
          return false if reference_id.nil? || !reference_id.is_a?(String)

          Hypertube::Core::ReferenceCache::ReferencesCache.instance.delete_reference(reference_id)
        end
      end
    end
  end
end
