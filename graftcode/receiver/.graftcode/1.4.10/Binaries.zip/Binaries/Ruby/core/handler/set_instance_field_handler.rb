# frozen_string_literal: true

require_relative 'abstract_handler'

module Hypertube
  module Core
    module Handler
      class SetInstanceFieldHandler < Hypertube::Core::Handler::AbstractHandler
        def initialize
          @required_parameters_count = 3
        end

        def process(command)
          set_instance_field(command)
        end

        def set_instance_field(command)
          validate(command, @required_parameters_count, self.class.name)

          instance = command.payload[0]
          field_name = command.payload[1].to_s
          new_value = command.payload[2]

          field = field_name.start_with?('@') ? field_name : "@#{field_name}"
          field_defined = begin
            instance.instance_variable_defined?(field)
          rescue NameError
            false
          end

          unless field_defined
            fields = instance.instance_variables

            value_type = new_value.nil? ? 'null' : new_value.class.name
            class_name = instance.class.name
            message = "Failed to set value of type #{value_type} for #{field_name} in class #{class_name}.\nAvailable public instance variables:\n"
            fields.each { |field_iter| message += "#{field_iter}\n" }
            raise ArgumentError, message
          end

          instance.instance_variable_set(field, new_value)
          instance
        end
      end
    end
  end
end
