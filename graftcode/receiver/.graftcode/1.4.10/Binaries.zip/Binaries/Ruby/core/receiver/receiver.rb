require_relative '../interpreter/interpreter'
require_relative '../../utils/runtime_logger'
require_relative '../protocol/command_serializer'
require_relative '../../utils/command'
require_relative '../../utils/os_helper'

module Hypertube
  module Core
    module Receiver
      class Receiver

        @unhandled_exception_logger_installed = false

        def self.install_unhandled_exception_logger
          return if @unhandled_exception_logger_installed
          @unhandled_exception_logger_installed = true
          at_exit do
            if $! && !$!.is_a?(SystemExit) && !$!.is_a?(Interrupt)
              warn "Hypertube unhandled exception: #{$!.full_message}"
            end
          end
        end

        def self.send_command(message_array)
          install_unhandled_exception_logger
          begin
            response_array = Hypertube::Core::Protocol::CommandSerializer.serialize(Hypertube::Core::Interpreter::Interpreter.process(message_array))
          rescue Exception => e
            message = "Error occurred in Hypertube::Sdk::RuntimeBridge Ruby Core: #{e.message}"
            puts message
            exception_command = Hypertube::Utils::Command.new(Hypertube::Utils::RuntimeNameHt::RUBY, Hypertube::Utils::CommandType::EXCEPTION, [])
            exception_command = exception_command.add_arg_to_payload(Hypertube::Utils::Exceptions::ExceptionType::EXCEPTION)
            exception_command = exception_command.add_arg_to_payload(Hypertube::Utils::Command.new(Hypertube::Utils::RuntimeNameHt::RUBY, Hypertube::Utils::CommandType::EXCEPTION, ["Ruby Core Error", "Ruby Core Error"]).to_s)
            exception_command = exception_command.add_arg_to_payload("Ruby Core Error")
            exception_command = exception_command.add_arg_to_payload(e.message)
            exception_command = exception_command.add_arg_to_payload("Hypertube::Core::Receiver::Receiver")
            exception_command = exception_command.add_arg_to_payload("send_command")
            exception_command = exception_command.add_arg_to_payload("undefined")
            exception_command = exception_command.add_arg_to_payload(__FILE__)
            response_array = Hypertube::Core::Protocol::CommandSerializer.serialize(exception_command)
          end
          [response_array.length, response_array]
        end

        def self.heart_beat(message_array)
          response_array = [message_array[11], message_array[12] - 2]
          [response_array.length, response_array]
        end

        def self.get_runtime_info
          Hypertube::Utils::RuntimeLogger.get_runtime_info(true)
        end
      end

    end
  end
end
