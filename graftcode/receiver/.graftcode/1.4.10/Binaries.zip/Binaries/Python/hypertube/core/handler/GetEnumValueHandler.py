from enum import Enum

from hypertube.core.handler.AbstractHandler import AbstractHandler


class GetEnumValueHandler(AbstractHandler):
    def __init__(self):
        self._required_parameters_count = 1

    def process(self, command):
        try:
            self.validate(command, self._required_parameters_count, "CreateEnumHandler")
            enum_object = command.payload[0]
            if isinstance(enum_object, Enum):
                return enum_object.value
            else:
                raise Exception("Argument is not enumerable")
        except Exception as e:
            exc_type, exc_value = type(e), e
            new_exc = exc_type(exc_value).with_traceback(e.__traceback__)
            raise new_exc from None
